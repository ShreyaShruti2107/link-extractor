// document.getElementById("text").addEventListener("click",write);

// var get=document.getElementById("text");
// var set;
// function write(){
//  let notification="Write your text to extract link.";
// document.getElementById("text").value=notification;
//     // document.getElementById("text").value=get;
//    get=document.getElementById("text").value;
//     set=get.value;
//     console.log(set);
// }

// console.log("hello world");
// let text=document.getElementById("text");
// var values;
// let notification="Write text here to extract link";
// let notice;
// function write(){
//     values=document.getElementById("text").value;
//     console.log(values);
//     notice=document.getElementById("text").value;
//     console.log(notice);
// }

// document.getElementById("text").addEventListener("mouseenter",effect);

// document.getElementById("text").addEventListener("click",write);
// function effect(){
//     document.getElementById("text").style.backgroundColor="Blue";
// }
// function write(){
//     console.log(document.getElementById("text").value);
// }

document.getElementById("text").addEventListener("mouseleave", write);

let text; let validtext = " ";

function write() {
    text = document.getElementById("text").value;

    document.getElementById("text").style.color = "Blue";
}

console.log(text);
function extract() {
    let check = text;

    document.getElementById("output").style.backgroundColor = "lightpink";
    // document.getElementById("output").innerHTML= "";
    for (var i = 0; i < text.length; i++) {

        validtext = "";
        if (text.slice(i, i + 7) == "http://" || text.slice(i, i + 4) == "www." || text.slice(i, i + 8) == "https://") {
            // console.log("found at", i);
            while (text[i] != " " && i < text.length) {
                // document.getElementById("output").innerHTML+=text[i];
                validtext += text[i];
                i++;
            }
            console.log(validtext);

            if (validtext.length > 3 || validtext.length > 4 || validtext.length > 5) {
                if (validtext.slice(-4, validtext.length) == ".com" || validtext.slice(-4, validtext.length) == ".org"
                    || validtext.slice(-4, validtext.length) == ".gov" || validtext.slice(-3, validtext.length) == ".in" || validtext.slice(-4, validtext.length) == ".net"
                    || validtext.slice(-4, validtext.length) == ".edu") {
                    document.getElementById("output").innerHTML +=`<a href="${validtext}" margin-left="0%">${validtext}</a>&nbsp;&nbsp;&nbsp;`;

                    //  var golink = document.createElement("button");
                    //  var text = document.createTextNode("Go link");
                    //  golink.appendChild(text);
                   const button = document.createElement('button');
                   console.log(button);
                   button.innerText="go-link";
                   button.id="mainbutton";
                   button.addEventListener('click',() => {
                    alert('Click on left link')
                   })


                    
                }

                // validtext = "";

                // document.getElementById("output").innertHTML+="    ";
                // var golink = document.createElement("button");
                // var text=document.createTextNode("Go link");
                // golink.appendChild(text);

                // let finallink = document.getElementById("outer");
                // finallink.appendChild(golink);
                // document.getElementById("output").innerHTML = "<br>";


            }

        }
    }
}